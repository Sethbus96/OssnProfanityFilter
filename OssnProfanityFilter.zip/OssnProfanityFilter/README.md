OssnProfanityFilter

This ossn component filters profane words on Ossn walls and replace those words with dashes("---")

